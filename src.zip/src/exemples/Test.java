package exemples;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import ppc.*;
import representations.*;

public class Test 
{
    public static void main(String[] args)
    {
        // domaines
        Set<String> dom_boolean = new HashSet(Arrays.asList("oui", "non"));
        Set<String> dom_puissance = new HashSet(Arrays.asList("basse", "moyenne", "haute"));
        
        // domaines restreints
        Set<String> rd_oui = new HashSet(Arrays.asList("oui"));
        Set<String> rd_non = new HashSet(Arrays.asList("non"));
        
        // variables
        Variable var_angine = new Variable("angine", dom_boolean);
        Variable var_fievre = new Variable("fievre", dom_puissance);
        Variable var_toux = new Variable("toux", dom_boolean);
        Variable var_grippe = new Variable("grippe", dom_boolean);
        Variable var_vaccination = new Variable("vaccination", dom_boolean);
        Variable var_fatigue = new Variable("fatigue", dom_boolean);
        Variable var_virus = new Variable("virus", dom_boolean);
        Variable var_sirop = new Variable("prise sirop", dom_boolean);
        Variable var_allergie = new Variable("allergie sucre", dom_puissance);
        Variable var_boutons = new Variable("boutons", dom_boolean);
        Variable var_oedeme = new Variable("oedeme", dom_boolean);
        Variable var_hypothermie = new Variable("hypothermie", dom_boolean);
        
        // lois
        Rule ar1_angine = new Rule(
            new HashSet(Arrays.asList(new RestrictedDomain(var_angine, rd_oui))),
            new HashSet(Arrays.asList(new RestrictedDomain(var_fievre, new HashSet(Arrays.asList("moyenne", "haute")))))     
        );
        
        Rule ar2_angine = new Rule(
            new HashSet(Arrays.asList(new RestrictedDomain(var_angine, rd_oui))),
            new HashSet(Arrays.asList(new RestrictedDomain(var_toux, new HashSet(Arrays.asList("oui")))))     
        );
        
        Rule ar1_grippe = new Rule(
            new HashSet(Arrays.asList(new RestrictedDomain(var_vaccination, rd_non))),
            new HashSet(Arrays.asList(new RestrictedDomain(var_fievre, new HashSet(Arrays.asList("haute")))))
        );
        
        Rule ar2_grippe = new Rule(
            new HashSet(Arrays.asList(new RestrictedDomain(var_vaccination, rd_non))),
            new HashSet(Arrays.asList(new RestrictedDomain(var_fatigue, new HashSet(Arrays.asList("haute")))))
        );
        
        Rule ar3_grippe = new Rule(
            new HashSet(Arrays.asList(new RestrictedDomain(var_grippe, rd_oui))),
            new HashSet(Arrays.asList(new RestrictedDomain(var_virus, rd_oui)))
        );
        
        Rule ar1_sirop = new Rule(
            new HashSet(Arrays.asList(new RestrictedDomain(var_sirop, rd_oui), new RestrictedDomain(var_allergie, new HashSet(Arrays.asList("moyenne"))))),
            new HashSet(Arrays.asList(new RestrictedDomain(var_boutons, rd_oui)))
        );
        
        Rule ar2_sirop = new Rule(
            new HashSet(Arrays.asList(new RestrictedDomain(var_sirop, rd_oui), new RestrictedDomain(var_allergie, new HashSet(Arrays.asList("haute"))))),
            new HashSet(Arrays.asList(new RestrictedDomain(var_oedeme, rd_oui)))
        );
        
        IncompatibilityConstraint ar1_hypo = new IncompatibilityConstraint(
            new HashSet(Arrays.asList(new RestrictedDomain(var_fievre, new HashSet(Arrays.asList("haute", "moyenne"))), new RestrictedDomain(var_hypothermie, rd_oui)))
        );
        
        Disjonction ar2_hypo = new Disjonction(
            new HashSet(Arrays.asList(new RestrictedDomain(var_fievre, new HashSet(Arrays.asList("basse"))), new RestrictedDomain(var_hypothermie, rd_non)))
        );
        
        // exemples de patients
        Map<Variable, String> patient1 = new HashMap<>();
        patient1.put(var_fievre, "moyenne");
        patient1.put(var_hypothermie, "non");
        patient1.put(var_angine, "oui");
        patient1.put(var_toux, "oui");
        
        Map<Variable, String> patient2 = new HashMap<>();
        patient2.put(var_fievre, "basse");
        patient2.put(var_hypothermie, "oui");
        patient2.put(var_angine, "oui");        
        patient2.put(var_toux, "non");
        
        Map<Variable, String> patient3 = new HashMap<>();
        patient3.put(var_fievre, "moyenne");
        patient3.put(var_allergie, "basse");
        patient3.put(var_vaccination, "non");
        patient3.put(var_sirop, "non");
        patient3.put(var_oedeme, "non");
        
        //System.out.println("patient3 sur ar1_grippe : " + ar1_grippe.isSatisfiedBy(patient3));
        
        // tests
        //System.out.println(art1_angine.isSatisfiedBy(patient1));
        //System.out.println(art1_angine.isSatisfiedBy(patient2));
        
        //System.out.println(art2_angine.isSatisfiedBy(patient1));
        //System.out.println(art2_angine.isSatisfiedBy(patient2));
        
        BackTracking chercheur = new BackTracking(
            new HashSet(Arrays.asList(
                ar1_angine, ar2_angine, 
                ar1_grippe, ar2_grippe, 
                ar3_grippe,
                ar1_sirop,
                ar2_sirop,
                ar1_hypo,
                ar2_hypo))
        );
        
        Set<Map<Variable, String>> solutions = chercheur.allSolutions();
        
        int i = 0;
        
        for(Map<Variable, String> solution : solutions)
        {
            i++;
            
            System.out.println("map " + i + " :\n" + ToString.mapToString(solution));
        }
    }
}
