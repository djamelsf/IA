package exemples;

import java.util.Arrays;
import java.util.HashSet;
import representations.*;

public class Test_simple 
{    
    public static void main(String[] args)
    {
        Variable x = new Variable("x", new HashSet(Arrays.asList("2", "3")));
        Variable y = new Variable("y", new HashSet(Arrays.asList("1", "2")));
        
        Rule x = new Rule(new HashSet)
    }
}