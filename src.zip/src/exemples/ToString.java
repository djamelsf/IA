package exemples;

import java.util.Map;
import representations.Variable;

public class ToString 
{
    public static String mapToString(Map<Variable, String> map)
    {
        String str = "";
        
        for(Map.Entry<Variable, String> keyset : map.entrySet())
            str += keyset.getKey().getName() + " -> " + keyset.getValue() + "\n";

        return str;
    }
}