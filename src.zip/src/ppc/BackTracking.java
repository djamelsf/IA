package ppc;

import exemples.ToString;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import representations.*;

public class BackTracking 
{
    private final Set<Variable> variables;
    private final Set<IConstraint> contraintes;
    
    public BackTracking(Set<IConstraint> contraintes)
    {
        this.contraintes = contraintes;
        
        variables = new HashSet<>();
        
        for(IConstraint constraint : contraintes)
            variables.addAll(constraint.getScope());
    }
    
    public Set<Map<Variable, String>> allSolutions()
    {
        Set<Map<Variable, String>> all = new HashSet<>();
        
        Map<Variable, String> res_partial = new HashMap<>();
        Deque<Variable> unassignedVariables = new ArrayDeque<>(variables);
        
        this.solutions(res_partial, unassignedVariables, all);
        
        return all;
    }
    
    void solutions_new(Map<Variable, String> res_partial, Deque<Variable> unassigned, Set<Map<Variable, String>> all)
    {
        if (unassigned.isEmpty())  // assignation complete
        {
            for(IConstraint contr : contraintes)
                if (!contr.isSatisfiedBy(res_partial))
                {
                    return;
                }
            
            Map<Variable, String> res = new HashMap<>();
            
            res.putAll(res_partial);
            
            all.add(res);
        }
        else
        {
            unassigned = new ArrayDeque<>(unassigned);
            
            for(Variable var : unassigned)
            {
                
            }
        }
    }
    
    void solutions(Map<Variable, String> res_partial, Deque<Variable> unassigned, Set<Map<Variable, String>> all)
    {
        if (unassigned.isEmpty())  // assignation complete
        {
            for(IConstraint contr : contraintes)
                if (!contr.isSatisfiedBy(res_partial))
                {
                    //System.out.println("invalid map : \n" + ToString.mapToString(res_partial));
                    return;
                }
            
            Map<Variable, String> res = new HashMap<>();
            
            res.putAll(res_partial);
            
            all.add(res);
        }
        else
        {
            unassigned = new ArrayDeque<>(unassigned);
            
            for(IConstraint constr : contraintes)
            {
                for(Variable var : constr.getScope())
                {
                    if (unassigned.contains(var))
                    {
                        unassigned.remove(var);
                        
                        for(String val : var.getDomain())
                        {
                            res_partial.put(var, val);
                            
                            if (constr.isSatisfiedBy(res_partial))
                            {
                                solutions(res_partial, unassigned, all);
                            }
                        }
                    }
                }
            }
        }
    }
}