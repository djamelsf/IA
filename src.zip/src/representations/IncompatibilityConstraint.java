package representations;

import java.util.Set;

public class IncompatibilityConstraint extends Rule
{
    public IncompatibilityConstraint(Set<RestrictedDomain> premisse) 
    {
        super(premisse, null);
    }    
}