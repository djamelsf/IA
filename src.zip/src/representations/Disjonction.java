package representations;

import java.util.Set;

public class Disjonction extends Rule
{
    public Disjonction(Set<RestrictedDomain> conclusion) 
    {
        super(null, conclusion);
    }    
}