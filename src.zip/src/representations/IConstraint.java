package representations;

import java.util.Map;
import java.util.Set;

public interface IConstraint 
{
    public Set<Variable> getScope();
    public boolean isSatisfiedBy(Map<Variable, String> sujet);
    
    @Override
    public String toString();
}
