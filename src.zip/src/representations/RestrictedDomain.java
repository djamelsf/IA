package representations;

import java.util.Set;

public class RestrictedDomain 
{
    private Variable variable;
    private Set<String> sousDomaine;

    public RestrictedDomain(Variable variable, Set<String> sousDomaine) 
    {
        this.variable = variable;
        this.sousDomaine = sousDomaine;
    }

    public Variable getVariable() 
    {
        return variable;
    }

    public Set<String> getSousDomaine() 
    {
        return sousDomaine;
    }
}