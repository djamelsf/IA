package representations;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Rule implements IConstraint 
{
    private Set<RestrictedDomain> premisse;
    private Set<RestrictedDomain> conclusion;
    
    private Set<Variable> scope;

    public Rule(Set<RestrictedDomain> premisse, Set<RestrictedDomain> conclusion) 
    {
        scope = new HashSet<>();
             
        if (premisse != null)
        {
            this.premisse = premisse;
           
            for(RestrictedDomain d : this.premisse)
                scope.add(d.getVariable());
        }
        
        if (conclusion != null)
        {
            this.conclusion = conclusion;
        
            for(RestrictedDomain d : this.conclusion)
                scope.add(d.getVariable());
        }
    }

    public Set<RestrictedDomain> getPremisse() 
    {
        return premisse;
    }

    public Set<RestrictedDomain> getConclusion() 
    {
        return conclusion;
    }
    
    @Override
    public Set<Variable> getScope()
    {
        return scope;
    }

    @Override
    public boolean isSatisfiedBy(Map<Variable, String> patient) 
    {
        boolean temp = true;
        
        // verifier premisse
        if (premisse != null)
        {
            for(RestrictedDomain rd : premisse)
            {
                temp &= rd.getSousDomaine().contains(patient.get(rd.getVariable()));

                if (!temp)
                    return true;
            }
        }
        
        if (temp && conclusion != null)
        {        
            // for(Map.Entry<Variable, String> var : conclusion.entrySet()) temp |= patient.get(var.getKey()).equals(var.getValue());
                        
            for(RestrictedDomain rd : conclusion)
                temp &= rd.getSousDomaine().contains(patient.get(rd.getVariable()));
            
            return temp;
        }
        else
            return true;
    }
    
    @Override
    public String toString()
    {
        String res = "";
        
        if (!premisse.isEmpty())
        {
            for(RestrictedDomain rd : premisse)
            {
                
            }
        }
        
        if (!conclusion.isEmpty())
        {
            
        }
        
        return res;
    }
}